﻿using System;

namespace BookManagement;

class Program
{
    static void Main(string[] args)
    {
        BookManagementApp app = new BookManagementApp();
        app.Run();
    }
}

